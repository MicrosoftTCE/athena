  function transform(d) {
    return "translate(" + d.x + "," + d.y + ")";
  }
function translateSVG(x, y) 
{
  return 'translate('+x+','+y+')';
}
function numCommas(numberStr)
{
  numberStr += '';
  x = numberStr.split('.');
  x1 = x[0];
  x2 = x.length > 1 ? '.' + x[1] : '';
  var rgx = /(\d+)(\d{3})/;
  
  while(rgx.test(x1)) 
  {
    x1 = x1.replace(rgx, '$1' + ',' + '$2');
  }

  return x1 + x2;
}

var color = d3.scale.category20();
var width = 1440;
var height = 450;
var force = d3.layout.force()
              .charge(-70)
              .linkDistance(15)
              .size([width, height]);



var organizations = {};
var filteredNodes = {};
var porucsCon = {};
var affilCon = {};
var fundingCon = {};
var investingCon = {};

var svg = d3.select(".content").append("svg").attr("height", height).attr("width", width).attr("viewBox", "0 0 1440 450");

var outer = svg.append("g");

//  Static Scale
//  Improve by dynamically obtaining min and max values
var empScale = d3.scale.sqrt().domain([10, 130000]).range([10, 50]);
var twitScale = d3.scale.sqrt().domain([10, 10000000]).range([10,50]);


d3.json("data/final.json", function(error, graph) {
   filteredNodes = (graph.nodes).filter(function(d){return d.type !== null;});
  fundingCon = (graph.fundingR).filter(function(d){return d.source < 50 && d.target < 50;});
  investingCon = (graph.investingR).filter(function(d){return d.source < 50 && d.target < 50;});
  porucsCon = (graph.porucs).filter(function(d){return d.source < 50 && d.target < 50;});
  affilCon = (graph.affiliations).filter(function(d){return d.source < 50 && d.target < 50;});

// var fundLinkNode = [];
// var investLinkNode = [];
// var porucsLinkNode = [];
// var affilLinkNode = [];

// graph.fundingR.forEach(function(link){
//   fundLinkNode.push({
//     source:graph.nodes[link.source],
//     target:graph.nodes[link.target]
//   });
// });

// graph.investingR.forEach(function(link){
//   investLinkNode.push({
//     source:graph.nodes[link.source],
//     target:graph.nodes[link.target]
//   });
// });

// graph.porucs.forEach(function(link){
//   porucsLinkNode.push({
//     source:graph.nodes[link.source],
//     target:graph.nodes[link.target]
//   });
// });

// graph.affiliations.forEach(function(link){
//   affilLinkNode.push({
//     source:graph.nodes[link.source],
//     target:graph.nodes[link.target]
//   });
// });

// force
//       .nodes(filteredNodes.concat(fundLinkNode))
//       .nodes(filteredNodes.concat(investLinkNode))
//       .nodes(filteredNodes.concat(porucsLinkNode))
//       .nodes(filteredNodes.concat(affilLinkNode))

var drag = force.drag()
    .on("dragstart", dragstart);

  force
      .nodes(filteredNodes)
      .links(fundingCon)
      .start();

  force 
      .nodes(filteredNodes)
      .links(investingCon)
      .start(); 

  force
      .nodes(filteredNodes)
      .links(porucsCon)
      .start();

  force
      .nodes(filteredNodes)
      .links(affilCon)
      .start();
  // console.log(graph);

  //  FUNDINGS
  var fundLink = svg.selectAll(".fund")
      .data(fundingCon)
    .enter().append("line")
      .attr("class", "fund")
      // .style("stroke-dasharray", ("3,3"))
      .style("stroke", "rgba(228,135,253,0.2)")
      .style("stroke-width", "1")
      .style("outline", "1px solid transparent");

    // .enter().append("line")
    //   .attr("class", "link")
    //   .style("stroke-width", function(d) { return Math.sqrt(d.value); });

  //  INVESTMENTS
  var investLink = svg.selectAll(".invest")
      .data(investingCon)
    .enter().append("line")
      .attr("class", "invest")
      // .style("stroke-dasharray", ("3,3"))
      .style("stroke", "rgba(112,173,71,0.2)")
      .style("stroke-width", "1").style("outline", "1px solid transparent");

  //  PARTNERSHIPS AND UNIDENTIFIED COLLABORATIONS
  var porucsLink = svg.selectAll(".porucs")
      .data(porucsCon)
    .enter().append("line")
      .attr("class", "porucs")
      .style("stroke", "rgba(31,78,121,0.2)")
      // .style("stroke-dasharray", ("3,3"))
      .style("stroke-width", "1").style("outline", "1px solid transparent");

  //  AFFILIATIONS
  var affilLink = svg.selectAll(".affil")
      .data(affilCon)
    .enter().append("line")
      .attr("class", "affil")
      .style("stroke", "rgba(251,199,53,0.2)")
      // .style("stroke-dasharray", ("3,3"))
      .style("stroke-width", "1").style("outline", "1px solid transparent");

  var nodeInit = svg.selectAll(".node")
      .data(filteredNodes)
    .enter().append("g").attr("class", "node").call(drag);
  
  var node = nodeInit.append("circle")
      .attr("r", function(d) {if(d.numemp !== null) return empScale(parseInt(d.numemp)); else return "7";})
      .style("fill", function(d) { if(d.type !== null)
                                                  {
                                                    if(d.type === "Individual")
                                                      return "rgb(255,185,0)";
                                                    if(d.type === "Non-Profit")
                                                      return "rgb(0,164,239)";
                                                    if(d.type === "For-Profit")
                                                      return "rgb(127,186,0)";
                                                    if(d.type === "Government")
                                                      return "rgb(242,80,34)";
                                                  } })
      .style("stroke-width", '1.5px')
      .style("stroke", 'white')




      .on('mouseover', handleNodeHover)
      .on('mouseout', offNode)
      .on('click', sinclick)
      .on("dblclick", dblclick);

      // function dragMotion()
      // {
      //   d3.select(this).on(drag);
      // }

var textElement = svg.selectAll('.node')
                     .append('text')
                     .text(function(d) {return d.name;})
                     .attr('transform', function(d) {if(d.numemp !== null)
                                                      {
                                                        return translateSVG(0, -(empScale(parseInt(d.numemp)) + 2));
                                                      }
                                                      else
                                                      { 
                                                        return translateSVG(0, -(empScale(parseInt(7)) + 2));
                                                      }
                                                    })
                     .style('font', '10px sans-serif')
                     .style('pointer-events', 'none')
                     .style('text-shadow', '0 1px 0 #fff, 1px 0 0 #fff, 0 -1px 0 #fff, -1px 0 0 #fff');

initialInfo();

 // Initial display on sidebar
function initialInfo(){
  var s = "";

  s = "<a href='bingMap.php' target='_blank'><img src='images/bingmap.png' height=100% width=100%/></a>"

  var countTypes = [0,0,0,0];
  var forProfitsArray = [];
  var nonProfitsArray = [];
  var governmentArray = [];
  var individualArray = [];

  for(var x = 0; x < filteredNodes.length; x++)
  {
    if(filteredNodes[x].type === "Individual")
    {
      individualArray.push(filteredNodes[x].name);
      countTypes[3]++;
    }
    if(filteredNodes[x].type === "Non-Profit")
    {      
      nonProfitsArray.push(filteredNodes[x].name);
      countTypes[1]++;
    }
    if(filteredNodes[x].type === "For-Profit")
    {      
      forProfitsArray.push(filteredNodes[x].name);
      countTypes[0]++;
    }
    if(filteredNodes[x].type === "Government")
    {      
      governmentArray.push(filteredNodes[x].name);
      countTypes[2]++;
    }
  } 


s += "<h3 style='padding-bottom:10px;'>Entity Breakdown</h3>"; 


  //  Printing to side panel within web application.
  d3.select('#info')
    .html(s)
    .style('list-style', 'square');


      

    d3.select('#info').append('div').attr('id', 'breakdown').style('width', '100%');

var x = d3.scale.linear()
    .domain([0, d3.max(countTypes)])
    .range([0, $('#breakdown').width()]);

  var typesColor = 0;
  var typesText = 0;

    d3.select("#breakdown")
    .selectAll("div")
      .data(countTypes)
    .enter().append("div")
      .style("width", function(d){
                          return x(d) + "px";
                      })
      .style("height", "20px")
      .style("font","10px sans-serif")
      .style("background-color",function(d){
                        if(typesColor === 0)
                        {
                          typesColor++;
                          return "rgb(127,186,0)";
                        }
                         if(typesColor === 1)
                        {
                          typesColor++;
                          return "rgb(0,164,239)";
                        }
                        if(typesColor === 2)
                        {
                          typesColor++;
                          return "rgb(242,80,34)";
                        }
                        if(typesColor === 3)
                        {
                          typesColor++;
                          return "rgb(255,185,0)";
                        } 
                      })
      .style("text-align","right")
      .style("padding","3px")
      .style("margin","1px")
      .style("color","white")
      .text(function(d){if(typesText === 0)
                        {
                          typesText++;
                          return "For-Profit: " + d;
                        }
                         if(typesText === 1)
                        {
                          typesText++;
                          return "Non-Profit: " + d;
                        }
                        if(typesText === 2)
                        {
                          typesText++;
                          return "Government: " + d;
                        }
                        if(typesText === 3)
                        {
                          typesText++;
                          return "Individual: " + d;
                        } 
                        });

      var t = "";

      t += "<h3 style='padding-top:15px; color:rgb(127,186,0);'>For-Profit (<strong>" + countTypes[0] + "</strong>):</h3> ";
      for(var x = 0; x < forProfitsArray.length; x++)
      {
        if(x === forProfitsArray.length - 1)
        {
          t += "<span style='font-size:16px;'>" + forProfitsArray[x] + "</span>";
        }
        else
        {
          t += "<span style='font-size:16px;'>" + forProfitsArray[x] + ", </span>";
        }
      }
      t += "<h3 style='padding-top:15px; color:rgb(0,164,239);'>Non-Profit (<strong>" + countTypes[1] + "</strong>):</h3> ";
      for(var x = 0; x < forProfitsArray.length; x++)
      {
        if(x === nonProfitsArray.length - 1)
        {
          t += "<span style='font-size:16px;'>" + nonProfitsArray[x] + "</span>";
        }
        else
        {
          t += "<span style='font-size:16px;'>" + nonProfitsArray[x] + ", </span>";
        }
      }
      t += "<h3 style='padding-top:15px; color:rgb(242,80,34);'>Government (<strong>" + countTypes[2] + "</strong>):</h3> ";
      for(var x = 0; x < governmentArray.length; x++)
      {
        if(x === governmentArray.length - 1)
        {
          t += "<span style='font-size:16px;'>" + governmentArray[x] + "</span>";
        }
        else
        {
          t += "<span style='font-size:16px;'>" + governmentArray[x] + ", </span>";
        }
      }
      t += "<h3 style='padding-top:15px; color:rgb(255,185,0);'>Individual (<strong>" + countTypes[3] + "</strong>):</h3> ";
      for(var x = 0; x < individualArray.length; x++)
      {
        if(x === individualArray.length - 1)
        {
          t += "<span style='font-size:16px;'>" + individualArray[x] + "</span>";
        }
        else
        {
          t += "<span style='font-size:16px;'>" + individualArray[x] + ", </span>";
        }
      }

      d3.select('#info')
        .append('text')
        .style('padding-bottom', '20px')
        .html(t);

}


function handleNodeHover(d) 
{


   var s = "";

   s = "<a href='bingMap.php' target='_blank'><img src='images/bingmap.png' height=100% width=100%/></a>"

  //  General Information
  s += '<h1>' + "<a href=" + '"' + d.weblink + '">' + d.name + '</a></h1>';
  
  if(d.location !== null)
  { 
    s += 'Location: ' + d.location + '<br/>'; 
  }
  else
  {
    s += 'Location: ' + 'N/A' + '<br/>';
  }

  s += 'Type of Entity: ' + d.type + '<br/>';

  if(d.type !== 'Individual')
  {
    if(d.numemp !== null)
    {
      s += 'Number of Employees: ' + numCommas(d.numemp) + '<br/>';
    }
    else
    {
      s += 'Number of Employees: ' + 'N/A' + '<br/>';
    }
  }

  if(d.twitterH === null)
  {
      s += 'Twitter Handle: ' + 'N/A' + '<br/>';
      s += 'Number of Twitter Followers: ' + 'N/A' + '<br/>';
  }
  else
  {
    var twitterLink = (d.twitterH).replace('@', '');

    twitterLink = 'https://twitter.com/' + twitterLink;
    s += 'Twitter Handle: ' + "<a href=" + '"' + twitterLink + '">' + d.twitterH + '</a><br/>';
    s += 'Number of Twitter Followers: ' + numCommas(d.followers) + '<br/>';
  }

  //  KEY PEOPLE
  var keyPeopleArr = [];

  if(d.people !== null)
  {
    s += '<br/>' + 'Key People Involved:' + '<ul>';
    keyPeopleArr = (d.people).split(", ");
    for(var count = 0; count < keyPeopleArr.length; count++)
    {
      s += '<li>' + '<a href="http://www.bing.com/search?q=' + (keyPeopleArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + keyPeopleArr[count] + '</a>' + '</li>'; 
    }
    s+= '</ul>';
  }

  //  FUNDING
  var fundOrgArr = [];
  var fundAmtArr = [];
  
  if(d.fundingR === null)
  {
    s += '<br/>' + d.name + ' receives no known funding from other organizations.' + '<br/>';
  }
  else
  {
    var counter = 0;
    var fundArr = [];
    var fundtemp = [];
    var holdTotalF;
    var holdIndividsF;

    //  If there's more than one funding contributor...
    if((d.fundingR).indexOf("; ") !== -1)
    {
      fundArr = (d.fundingR).split("; ");
      for(var count = 0; count < fundArr.length; count++)
      {
        fundtemp = fundArr[count].split(":");
        fundOrgArr.push(fundtemp[0]);
        fundAmtArr.push(fundtemp[1]);

        if(fundOrgArr[count] === "Total")
        {
          holdTotalF = fundAmtArr[count];
          continue;
        }
        
        if(fundOrgArr[count] === "Individuals")
        {
          holdIndividsF = fundAmtArr[count];
          continue;
        }
        
        if(fundAmtArr[count] === 'null')
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives funding from the following organizations:' + '<ul>';
            counter++;
          }
          
          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (fundOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + fundOrgArr[count] + '</a>' + ': <strong style="color:rgb(255,185,0);">unknown amount</strong>' + '</li>'; 
        }
        else
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives funding by the following organizations:' + '<ul>';
            counter++;
          }
          
          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (fundOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + fundOrgArr[count] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(fundAmtArr[count]) + '</strong>' + '</li>';
        }
      }
    }
    else
    {
      fundArr = (d.fundingR).split(":");
      
      if(fundArr[0] === "Total")
      {
        holdTotalF = fundAmtArr[count];
      }
      else if(fundArr[0] === "Individuals")
      {
        holdIndividsF = fundAmtArr[count];
      }
      else
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (fundArr[0]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + fundArr[0] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(fundArr[1]) + '</strong>' + '</li>';
      }
    }

    s += '</ul>';
    
    if(!isNaN(holdIndividsF)) 
    {
      s += 'Individuals provided $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdIndividsF) + '</strong> in fundings.<br/>';
    }
    
    if(!isNaN(holdTotalF)) 
    {
      s += 'The total amount of funding received was $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdTotalF) + '</strong>.<br/>';
    }
  }

  //  INVESTING
  var investOrgArr = [];
  var investAmtArr = [];
  var holdTotalI;
  var holdIndividsI

  if(d.investmentR === null)
  {
    s += '<br/>' + d.name + ' receives no known investments from other organizations.' + '<br/>';
  }
  else
  {    
    var counter = 0;    
    var investArr = [];
    var investtemp = [];

    //  If there's more than one funding contributor...
    if((d.investmentR).indexOf("; ") !== -1)
    {
      investArr = (d.investmentR).split("; ");

      for(var count = 0; count < investArr.length; count++)
      {
        investtemp = investArr[count].split(":");
        investOrgArr.push(investtemp[0]);
        investAmtArr.push(investtemp[1]);
        
        if(investOrgArr[count] === "Total")
        {
          holdTotalI = investAmtArr[count]; 
          continue;
        }
    
        if(investOrgArr[count] === "Individuals")
        {
          holdIndividsI = investAmtArr[count]; 
          continue;
        }
    
        if(investAmtArr[count] === 'null')
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives investments from the following organizations:' + '<ul>';
            counter++;
          }

          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (investOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + investOrgArr[count] + '</a>' + ': <strong style="color:rgb(255,185,0);">unknown amount</strong>' + '</li>'; 
        }
        else
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives investments from the following organizations:' + '<ul>';
            counter++;
          }

          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (investOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + investOrgArr[count] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(investAmtArr[count]) + '</strong>' + '</li>'; 
        }
      }
    }
    else
    {
      investArr = (d.investmentR).split(":");

      if(investArr[0] === "Total")
      {
          holdTotalI = investAmtArr[count];
      }
      else if(investArr[0] === "Individuals")
      {
          holdIndividsI = investAmtArr[count];
      }
      else
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (investArr[0]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + investArr[0] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(investArr[1]) + '</strong>' + '</li>';
      }
    }

    s += '</ul>'; 

    if(!isNaN(holdIndividsI)) 
    {
      s += 'Individuals provided $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdIndividsI) + '</strong> in investments.<br/>';
    }
    
    if(!isNaN(holdTotalI)) 
    {
      s += 'The total amount of investments received was $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdTotalI) + '</strong>.<br/>';
    }
  }

  //  AFFILIATIONS
  if(d.affil === null)
  {
    s += '<br/>' + d.name + ' has no known affiliations.' + '<br/>';
  }
  else 
  {
    s += '<br/>' + d.name + ' is affiliated with the following organizations:' + '<ul>';
    var affilArr = [];
    var affiltemp = [];

    //  If there's more than one affiliation...
    if((d.affil).indexOf("; ") !== -1)
    {
      affilArr = (d.affil).split("; ");
      for(var count = 0; count < affilArr.length; count++)
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (affilArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + affilArr[count] + '</a>' + '</li>';
      }
    }
    else
    {
      s += '<li>' + '<a href="http://www.bing.com/search?q=' + (d.affil).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + d.affil + '</a>' + '</li>';
    }

    s += '</ul>'; 
  }

  //  PARTNERSHIPS OR UNIDENTIFIED COLLABORATIONS
  if(d.poruc === null)
  {
    s += '<br/>' + d.name + ' has no known partnerships or unidentified collaborations.' + '<br/>';
  }
  else 
  {
    s += '<br/>' + d.name + ' has the following partnerships or unidentified collaborations:' + '<ul>';
    var porucArr = [];
    var poructemp = [];

    //  If there's more than one affiliation...
    if((d.poruc).indexOf("; ") !== -1)
    {
      porucArr = (d.poruc).split("; ");
      for(var count = 0; count < porucArr.length; count++)
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (porucArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + porucArr[count] + '</a>' + '</li>';
      }
    }
    else
    {
      s += '<li>' + '<a href="http://www.bing.com/search?q=' + (d.poruc).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + d.poruc + '</a>' + '</li>';
    }

    s += '</ul>'; 
  }

  //  Printing to side panel within web application.
  d3.select('#info')
    .html(s)
    .style('list-style', 'square');

  fundLink.style('stroke-width', function(l)
  { 
    if(d === l.source || d === l.target) 
    {

      return 1;
    }
  })
    .style("opacity", function(l){
              if(d === l.source || d === l.target)
              {
                nodeInit.style("opacity", function(d){if(d === l.source || d === l.target)
                                             {
                                                return "1";
                                              }
                                              else
                                                {return "0.05";}
                                            });
                return "1";
              }
               else
                return "0.05";
            }).style("stroke", function(l){if(d === l.source || d === l.target) return "rgb(228,135,253)";
                                else
                                {
                                  fundLink.style("stroke", "rgb(228,135,253)");
                investLink.style("stroke", "rgb(112,173,71)");
                porucsLink.style("stroke", "rgb(31,78,121)");
      affilLink.style("stroke", "rgb(251,199,53)");
                                }
  });

  investLink.style('stroke-width', function(l)
  {
              if(d === l.source || d === l.target) 
    {

      return 1;
    }
  })
            .style("opacity", function(l){
              if(d === l.source || d === l.target)
                {
                nodeInit.style("opacity", function(d){if(d === l.source || d === l.target)
                                             {
                                                return "1";
                                              }
                                              else
                                                {return "0.05";}
                                            });
                return "1";
              }
               else
                return "0.05";
            })
            .style("stroke", function(l){
              if(d === l.source || d === l.target)
                return "rgb(112,173,71)";
               else
              {
fundLink.style("stroke", "rgb(228,135,253)");
                investLink.style("stroke", "rgb(112,173,71)");
                porucsLink.style("stroke", "rgb(31,78,121)");
      affilLink.style("stroke", "rgb(251,199,53)");
              }
          });

  porucsLink.style('stroke-width', function(l)
  {
              if(d === l.source || d === l.target) 
    {

      return 1;
    }
  })
          .style("opacity", function(l){
              if(d === l.source || d === l.target)
               {
                nodeInit.style("opacity", function(d){if(d === l.source || d === l.target)
                                             {
                                                return "1";
                                              }
                                              else
                                                {return "0.05";}
                                            });
                return "1";
              }
               else
                return "0.05";
            })
          .style("stroke", function(l){
              if(d === l.source || d === l.target)
                return "rgb(31,78,121)";
              else
              {

               fundLink.style("stroke", "rgb(228,135,253)");
                investLink.style("stroke", "rgb(112,173,71)");
                porucsLink.style("stroke", "rgb(31,78,121)");
      affilLink.style("stroke", "rgb(251,199,53)");
              }
          });

  affilLink.style('stroke-width', function(l)
  {
              if(d === l.source || d === l.target) 
    {

      return 1;
    }
  }).style("opacity", function(l){
              if(d === l.source || d === l.target)
               {
                nodeInit.style("opacity", function(d){if(d === l.source || d === l.target)
                                             {
                                                return "1";
                                              }
                                              else
                                                {return "0.05";}
                                            });
                return "1";
              }
               else
                return "0.05";
            }).style("stroke", function(l){
              if(d === l.source || d === l.target)
                return "rgb(251,199,53)";
              else
              {

                fundLink.style("stroke", "rgb(228,135,253)");
                investLink.style("stroke", "rgb(112,173,71)");
                porucsLink.style("stroke", "rgb(31,78,121,)");
      affilLink.style("stroke", "rgb(251,199,53)");

              }
          });

            //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborFund = graph.fundingR.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborInvest = graph.investingR.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborPorucs = graph.porucs.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborAffil = graph.affiliations.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              svg.selectAll('.node').filter(function(l){
                  return neighborFund.indexOf(l.index) > -1;
              }).style("opacity", "1"); 
              
              svg.selectAll('.node').filter(function(l){
                  return neighborInvest.indexOf(l.index) > -1;
              }).style("opacity", "1"); 

              svg.selectAll('.node').filter(function(l){
                  return neighborPorucs.indexOf(l.index) > -1;
              }).style("opacity", "1"); 

              svg.selectAll('.node').filter(function(l){
                  return neighborAffil.indexOf(l.index) > -1;
              }).style("opacity", "1"); 

}

function offNode()
{

  nodeInit.style("opacity", "1").style("z-index", "99");

  fundLink.each(function(){this.parentNode.insertBefore(this, this);});
  investLink.each(function(){this.parentNode.insertBefore(this, this);});
  porucsLink.each(function(){this.parentNode.insertBefore(this, this);});
  affilLink.each(function(){this.parentNode.insertBefore(this, this);});

  fundLink
          // .style("stroke-dasharray", ("3,3"))
          .style("stroke", "rgb(228,135,253)")
          .style("opacity", "0.2")
          .style("stroke-width", "1px" ).style("z-index", "0");

  investLink
            // .style("stroke-dasharray", ("3,3"))
            .style("stroke", "rgb(112,173,71)")
            .style("opacity", "0.2")
            .style("stroke-width", "1px" ).style("z-index", "0");
      
  porucsLink
            // .style("stroke-dasharray", ("3,3"))
            .style("stroke", "rgb(31,78,121)")
            .style("opacity", "0.2")
            .style("stroke-width", "1px" ).style("z-index", "0");
      
  affilLink
            // .style("stroke-dasharray", ("3,3"))
           .style("stroke", "rgb(251,199,53)")
           .style("opacity", "0.2")
           .style("stroke-width", "1px" ).style("z-index", "0");
}

function handleClickNodeHover(d) 
{


   var s = "";

   s = "<a href='bingMap.php' target='_blank'><img src='images/bingmap.png' height=100% width=100%/></a>"

  //  General Information
  s += '<h1>' + "<a href=" + '"' + d.weblink + '">' + d.name + '</a></h1>';
  
  if(d.location !== null)
  { 
    s += 'Location: ' + d.location + '<br/>'; 
  }
  else
  {
    s += 'Location: ' + 'N/A' + '<br/>';
  }

  s += 'Type of Entity: ' + d.type + '<br/>';

  if(d.type !== 'Individual')
  {
    if(d.numemp !== null)
    {
      s += 'Number of Employees: ' + numCommas(d.numemp) + '<br/>';
    }
    else
    {
      s += 'Number of Employees: ' + 'N/A' + '<br/>';
    }
  }

  if(d.twitterH === null)
  {
      s += 'Twitter Handle: ' + 'N/A' + '<br/>';
      s += 'Number of Twitter Followers: ' + 'N/A' + '<br/>';
  }
  else
  {
    var twitterLink = (d.twitterH).replace('@', '');

    twitterLink = 'https://twitter.com/' + twitterLink;
    s += 'Twitter Handle: ' + "<a href=" + '"' + twitterLink + '">' + d.twitterH + '</a><br/>';
    s += 'Number of Twitter Followers: ' + numCommas(d.followers) + '<br/>';
  }

  //  KEY PEOPLE
  var keyPeopleArr = [];

  if(d.people !== null)
  {
    s += '<br/>' + 'Key People Involved:' + '<ul>';
    keyPeopleArr = (d.people).split(", ");
    for(var count = 0; count < keyPeopleArr.length; count++)
    {
      s += '<li>' + '<a href="http://www.bing.com/search?q=' + (keyPeopleArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + keyPeopleArr[count] + '</a>' + '</li>'; 
    }
    s+= '</ul>';
  }

  //  FUNDING
  var fundOrgArr = [];
  var fundAmtArr = [];
  
  if(d.fundingR === null)
  {
    s += '<br/>' + d.name + ' receives no known funding from other organizations.' + '<br/>';
  }
  else
  {
    var counter = 0;
    var fundArr = [];
    var fundtemp = [];
    var holdTotalF;
    var holdIndividsF;

    //  If there's more than one funding contributor...
    if((d.fundingR).indexOf("; ") !== -1)
    {
      fundArr = (d.fundingR).split("; ");
      for(var count = 0; count < fundArr.length; count++)
      {
        fundtemp = fundArr[count].split(":");
        fundOrgArr.push(fundtemp[0]);
        fundAmtArr.push(fundtemp[1]);

        if(fundOrgArr[count] === "Total")
        {
          holdTotalF = fundAmtArr[count];
          continue;
        }
        
        if(fundOrgArr[count] === "Individuals")
        {
          holdIndividsF = fundAmtArr[count];
          continue;
        }
        
        if(fundAmtArr[count] === 'null')
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives funding from the following organizations:' + '<ul>';
            counter++;
          }
          
          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (fundOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + fundOrgArr[count] + '</a>' + ': <strong style="color:rgb(255,185,0);">unknown amount</strong>' + '</li>'; 
        }
        else
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives funding by the following organizations:' + '<ul>';
            counter++;
          }
          
          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (fundOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + fundOrgArr[count] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(fundAmtArr[count]) + '</strong>' + '</li>';
        }
      }
    }
    else
    {
      fundArr = (d.fundingR).split(":");
      
      if(fundArr[0] === "Total")
      {
        holdTotalF = fundAmtArr[count];
      }
      else if(fundArr[0] === "Individuals")
      {
        holdIndividsF = fundAmtArr[count];
      }
      else
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (fundArr[0]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + fundArr[0] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(fundArr[1]) + '</strong>' + '</li>';
      }
    }

    s += '</ul>';
    
    if(!isNaN(holdIndividsF)) 
    {
      s += 'Individuals provided $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdIndividsF) + '</strong> in fundings.<br/>';
    }
    
    if(!isNaN(holdTotalF)) 
    {
      s += 'The total amount of funding received was $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdTotalF) + '</strong>.<br/>';
    }
  }

  //  INVESTING
  var investOrgArr = [];
  var investAmtArr = [];
  var holdTotalI;
  var holdIndividsI

  if(d.investmentR === null)
  {
    s += '<br/>' + d.name + ' receives no known investments from other organizations.' + '<br/>';
  }
  else
  {    
    var counter = 0;    
    var investArr = [];
    var investtemp = [];

    //  If there's more than one funding contributor...
    if((d.investmentR).indexOf("; ") !== -1)
    {
      investArr = (d.investmentR).split("; ");

      for(var count = 0; count < investArr.length; count++)
      {
        investtemp = investArr[count].split(":");
        investOrgArr.push(investtemp[0]);
        investAmtArr.push(investtemp[1]);
        
        if(investOrgArr[count] === "Total")
        {
          holdTotalI = investAmtArr[count]; 
          continue;
        }
    
        if(investOrgArr[count] === "Individuals")
        {
          holdIndividsI = investAmtArr[count]; 
          continue;
        }
    
        if(investAmtArr[count] === 'null')
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives investments from the following organizations:' + '<ul>';
            counter++;
          }

          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (investOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + investOrgArr[count] + '</a>' + ': <strong style="color:rgb(255,185,0);">unknown amount</strong>' + '</li>'; 
        }
        else
        {
          if(counter === 0)
          {
            s += '<br/>' + d.name + ' receives investments from the following organizations:' + '<ul>';
            counter++;
          }

          s += '<li>' + '<a href="http://www.bing.com/search?q=' + (investOrgArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + investOrgArr[count] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(investAmtArr[count]) + '</strong>' + '</li>'; 
        }
      }
    }
    else
    {
      investArr = (d.investmentR).split(":");

      if(investArr[0] === "Total")
      {
          holdTotalI = investAmtArr[count];
      }
      else if(investArr[0] === "Individuals")
      {
          holdIndividsI = investAmtArr[count];
      }
      else
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (investArr[0]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + investArr[0] + '</a>' + ': $' + '<strong style="color:rgb(127,186,0);">' + numCommas(investArr[1]) + '</strong>' + '</li>';
      }
    }

    s += '</ul>'; 

    if(!isNaN(holdIndividsI)) 
    {
      s += 'Individuals provided $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdIndividsI) + '</strong> in investments.<br/>';
    }
    
    if(!isNaN(holdTotalI)) 
    {
      s += 'The total amount of investments received was $' + '<strong style="color:rgb(127,186,0);">' + numCommas(holdTotalI) + '</strong>.<br/>';
    }
  }

  //  AFFILIATIONS
  if(d.affil === null)
  {
    s += '<br/>' + d.name + ' has no known affiliations.' + '<br/>';
  }
  else 
  {
    s += '<br/>' + d.name + ' is affiliated with the following organizations:' + '<ul>';
    var affilArr = [];
    var affiltemp = [];

    //  If there's more than one affiliation...
    if((d.affil).indexOf("; ") !== -1)
    {
      affilArr = (d.affil).split("; ");
      for(var count = 0; count < affilArr.length; count++)
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (affilArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + affilArr[count] + '</a>' + '</li>';
      }
    }
    else
    {
      s += '<li>' + '<a href="http://www.bing.com/search?q=' + (d.affil).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + d.affil + '</a>' + '</li>';
    }

    s += '</ul>'; 
  }

  //  PARTNERSHIPS OR UNIDENTIFIED COLLABORATIONS
  if(d.poruc === null)
  {
    s += '<br/>' + d.name + ' has no known partnerships or unidentified collaborations.' + '<br/>';
  }
  else 
  {
    s += '<br/>' + d.name + ' has the following partnerships or unidentified collaborations:' + '<ul>';
    var porucArr = [];
    var poructemp = [];

    //  If there's more than one affiliation...
    if((d.poruc).indexOf("; ") !== -1)
    {
      porucArr = (d.poruc).split("; ");
      for(var count = 0; count < porucArr.length; count++)
      {
        s += '<li>' + '<a href="http://www.bing.com/search?q=' + (porucArr[count]).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + porucArr[count] + '</a>' + '</li>';
      }
    }
    else
    {
      s += '<li>' + '<a href="http://www.bing.com/search?q=' + (d.poruc).replace(" ", "%20") + '&go=Submit&qs=bs&form=QBRE" target="_blank">' + d.poruc + '</a>' + '</li>';
    }

    s += '</ul>'; 
  }

  //  Printing to side panel within web application.
  d3.select('#info')
    .html(s)
    .style('list-style', 'square');

}

// var toggleCount = 0;

function sinclick(d) {


// $.ajax({
//  url: 'http://localhost/',
//  data: 'your image',
//  success: function(){window.open('http://localhost/civicmap/bingmap.php');},
//  async: false
// });

  // $.post("bingMap.php", { name : "value" },
  //         function (data) {
  //            window.open("http://www.google.com", "MyWindow");
  //         }, "text");



  // if(toggleCount%2 === 0)
  // {
  d3.select(this).on('mouseout', null);



  node.filter(function(singleNode){
    if(singleNode !== d)
    {
      return singleNode
    }
  }).on('mouseover', null)
    .on('mouseout', null);

    //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborFund = graph.fundingR.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborInvest = graph.investingR.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborPorucs = graph.porucs.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              //http://stackoverflow.com/questions/16857806/apply-several-mouseover-events-to-neighboring-connected-nodes
            var neighborAffil = graph.affiliations.filter(function(link){
              return link.source.index === d.index || link.target.index === d.index;}).map(function(link){
                return link.source.index === d.index ? link.target.index : link.source.index;
            });

              node.filter(function(l){
                  return neighborFund.indexOf(l.index) > -1;
              }).on('mouseover', handleClickNodeHover); 
              
              node.filter(function(l){
                  return neighborInvest.indexOf(l.index) > -1;
              }).on('mouseover', handleClickNodeHover); 

              node.filter(function(l){
                  return neighborPorucs.indexOf(l.index) > -1;
              }).on('mouseover', handleClickNodeHover);

              node.filter(function(l){
                  return neighborAffil.indexOf(l.index) > -1;
              }).on('mouseover', handleClickNodeHover);

  // d3.selectAll('.node').filter(function(singleNode){
  //   if(singleNode !== d)
  //     return singleNode;
  // }).style('stroke-width','black');

    // d3.select('svg').on('click', function(){

    //   d3.select(this).on('mouseout', offNode);

    //       d3.selectAll('.node').filter(function(node){
    //         if(d !== node)
    //         return node; 
    //       }).on('mouseover', handleNodeHover);

    // });
  // }
  // else 
  // {
  // d3.select(this).on('mouseout', offNode);
  // }
  // toggleCount++;

}

// var drag = d3.behavior.drag()
//     .on("dragstart", function(d){
//         //do some drag start stuff...
//     })
//     .on("drag", function(d){
//         //hey we're dragging, let's update some stuff
//         d3.selectAll(".node").forEach(function(d,i){if(d !== this) d3.select(node[i]).on("mouseout", null);});
//     })
//     .on("dragend", function(d){
//         //we're done, end some stuff
//     });

function dblclick(d) {
  d3.select(this).classed("fixed", d.fixed = false);
}

function dragstart(d) {

  d3.select(this).classed("fixed", d.fixed = true);
}



  force.on("tick", function() {



    fundLink.each(function() {this.parentNode.insertBefore(this, this); });
  investLink.each(function() {this.parentNode.insertBefore(this, this); });
  porucsLink.each(function() {this.parentNode.insertBefore(this, this); });
  affilLink.each(function() {this.parentNode.insertBefore(this, this); });

    fundLink.attr("x1", function(d) { return d.source.x = Math.max(50, Math.min(width - 50, d.source.x)); })
        .attr("y1", function(d) { return d.source.y = Math.max(50, Math.min(height - 50, d.source.y)); })
        .attr("x2", function(d) { return d.target.x = Math.max(50, Math.min(width - 50, d.target.x)); })
        .attr("y2", function(d) { return d.target.y= Math.max(50, Math.min(height - 50, d.target.y)); });

    investLink.attr("x1", function(d) { return d.source.x = Math.max(50, Math.min(width - 50, d.source.x)); })
        .attr("y1", function(d) { return d.source.y = Math.max(50, Math.min(height - 50, d.source.y)); })
        .attr("x2", function(d) { return d.target.x = Math.max(50, Math.min(width - 50, d.target.x)); })
        .attr("y2", function(d) { return d.target.y= Math.max(50, Math.min(height - 50, d.target.y)); });

    porucsLink.attr("x1", function(d) { return d.source.x = Math.max(50, Math.min(width - 50, d.source.x)); })
        .attr("y1", function(d) { return d.source.y = Math.max(50, Math.min(height - 50, d.source.y)); })
        .attr("x2", function(d) { return d.target.x = Math.max(50, Math.min(width - 50, d.target.x)); })
        .attr("y2", function(d) { return d.target.y= Math.max(50, Math.min(height - 50, d.target.y)); });

    affilLink.attr("x1", function(d) { return d.source.x = Math.max(50, Math.min(width - 50, d.source.x)); })
        .attr("y1", function(d) { return d.source.y = Math.max(50, Math.min(height - 50, d.source.y)); })
        .attr("x2", function(d) { return d.target.x = Math.max(50, Math.min(width - 50, d.target.x)); })
        .attr("y2", function(d) { return d.target.y= Math.max(50, Math.min(height - 50, d.target.y)); });

    nodeInit.attr("x", function(d) { return d.x = Math.max(50, Math.min(width - 50, d.x)); })
        .attr("y", function(d) { return d.y = Math.max(50, Math.min(height - 50, d.y)); });

        // fundLinkNode.attr("cx", function(d){return d.x = (d.source.x + d.target.x) * 0.5;})
        //         .attr("cy", function(d){return d.y = (d.source.y + d.target.y) * 0.5;});
        // investLinkNode.attr("cx", function(d){return d.x = (d.source.x + d.target.x) * 0.5;})
        //         .attr("cy", function(d){return d.y = (d.source.y + d.target.y) * 0.5;});
        // porucsLinkNode.attr("cx", function(d){return d.x = (d.source.x + d.target.x) * 0.5;})
        //         .attr("cy", function(d){return d.y = (d.source.y + d.target.y) * 0.5;});
        // affilLinkNode.attr("cx", function(d){return d.x = (d.source.x + d.target.x) * 0.5;})
        //         .attr("cy", function(d){return d.y = (d.source.y + d.target.y) * 0.5;});
          nodeInit.attr('transform', function(d) {return translateSVG(d.x, d.y);});

  }).on("end", function() {d3.selectAll(".example .input-control input").property('disabled', false);});

function zoom(){
                return d3.behavior.zoom();
            }

var zoom = zoom();

            function zoomed(){
                //if(flag){
                    console.log("zoomed");
                    outer.attr("transform","translate(" + [0,0] + ")  scale(" + d3.event.scale + ")");
                //}
            }
            zoom.on("zoom",zoomed);

            outer.call(zoom);

            d3.selectAll('#cb_fund, #cb_invest, #cb_porucs, #cb_affil').on('click', function() 
{
  //  Form links for funds.
  if(document.getElementById("cb_fund").checked)
  {
    // drawFundLink();
    d3.selectAll(".fund").style("visibility", "visible");
     
  }
  else
  {
    // d3.selectAll(".fund").remove();
    d3.selectAll(".fund").style("visibility", "hidden");
  }
  //  Form links for investments.
  if(document.getElementById("cb_invest").checked)
  {
    // drawInvestLink();
    d3.selectAll(".invest").style("visibility", "visible");
    
  }
  else
  {
    // d3.selectAll(".invest").remove();
    d3.selectAll(".invest").style("visibility", "hidden");
    
  }
  //  Form links for partnerships or unidentified collaborations.
  if(document.getElementById("cb_porucs").checked)
  {
    // drawInvestLink();
    d3.selectAll(".porucs").style("visibility", "visible");
   
  }
  else
  {
    // d3.selectAll(".porucs").remove();
    d3.selectAll(".porucs").style("visibility", "hidden");
 
  }
  //  Form links for affiliations.
  if(document.getElementById("cb_affil").checked)
  {
    // drawInvestLink();
    d3.selectAll(".affil").style("visibility", "visible");
    
  }
  else
  {
    // d3.selectAll(".porucs").remove();
    d3.selectAll(".affil").style("visibility", "hidden");
  
  }
});



// d3.selectAll(".node").filter(function(d) { if (d.type === "For-Profit"){ forprofitNodes.push(this);}});
// d3.selectAll(".node").filter(function(d) { if (d.type === "Non-Profit"){ nonprofitNodes.push(this);}});
// d3.selectAll(".node").filter(function(d) { if (d.type === "Government"){ governmentNodes.push(this);}});
// d3.selectAll(".node").filter(function(d) { if (d.type === "Individual"){ individNodes.push(this);}});


d3.selectAll('#cb_individ').on('click', function() 
{

    if(document.getElementById("cb_individ").checked)
    {

      d3.selectAll(".node").filter(function(d) { if (d.type === "Individual"){ 

              //  For funding connections

                   
                  var fNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      fundingCon.forEach(function(fundNodeCon0){
                        if(node0 === fundNodeCon0.source || node0 === fundNodeCon0.target){
                          fNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });


                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray0.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For investing connections

                  var iNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      investingCon.forEach(function(investNodeCon0){
                        if(node0 === investNodeCon0.source || node0 === investNodeCon0.target){
                          iNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });


                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray0.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      porucsCon.forEach(function(porucsNodeCon0){
                        if(node0 === porucsNodeCon0.source || node0 === porucsNodeCon0.target){
                          pcNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });

                  var pcNCIndex0 = 0;
                    
                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray0.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      affilCon.forEach(function(affilNodeCon0){
                        if(node0 === affilNodeCon0.source || node0 === affilNodeCon0.target){
                          aNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });

                  var aNCIndex0 = 0;
                    
                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray0.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

        return this;}}).style("visibility", "visible");
               // d3.selectAll(".fund").filter(function(d) {if (currentNode === d.source || currentNode === d.target) return this; }).style("visibility", "visible");
               // d3.selectAll(".invest").filter(function(d){if (currentNode === d.source || currentNode === d.target) return this; }).style("visibility", "visible");
               // d3.selectAll(".porucs").filter(function(d) {if (currentNode === d.source || currentNode === d.target) return this; }).style("visibility", "visible");
               // d3.selectAll(".affil").filter(function(d) {if (currentNode === d.source || currentNode === d.target) return this; }).style("visibility", "visible"); 
                  
                
    }
       if(!document.getElementById("cb_individ").checked)

    {

      d3.selectAll(".node").filter(function(d) { if (d.type === "Individual"){ 



                             //  For funding connections

                  var fNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      fundingCon.forEach(function(fundNodeCon0){
                        if(node0 === fundNodeCon0.source || node0 === fundNodeCon0.target){
                          fNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });
          
                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray0.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                    
                  });

                  //  For investing connections

                  var iNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      investingCon.forEach(function(investNodeCon0){
                        if(node0 === investNodeCon0.source || node0 === investNodeCon0.target){
                          iNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });


                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray0.indexOf(i)>-1)
                    {

                      return "hidden";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      porucsCon.forEach(function(porucsNodeCon0){
                        if(node0 === porucsNodeCon0.source || node0 === porucsNodeCon0.target){
                          pcNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });


                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray0.indexOf(i) > -1)
                    {
                    pcNCIndex0++;

                      return "hidden";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray0 = [];
                  var countIndex0 = 0;

                  filteredNodes.forEach(function(node0){
                    if(node0.type === 'Individual')
                    {
                      affilCon.forEach(function(affilNodeCon0){
                        if(node0 === affilNodeCon0.source || node0 === affilNodeCon0.target){
                          aNCArray0.push(countIndex0);//  store positions inside of array...
                        }
                        countIndex0++;
                      });
                      countIndex0 = 0;
                    }
                  });

                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray0.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                  });

                  console.log(fNCArray0);
                                    console.log(iNCArray0);
                  console.log(pcNCArray0);
                                    console.log(aNCArray0);

                                    // return;


        return this;}}).style("visibility", "hidden");
        
     
    }
   
    

});

  d3.selectAll('#cb_nonpro').on('click', function()
  {

       if(document.getElementById("cb_nonpro").checked)
    {
      d3.selectAll(".node").filter(function(d) { if (d.type === "Non-Profit"){


      //  For funding connections

                  var fNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      fundingCon.forEach(function(fundNodeCon1){
                        if((node1 === fundNodeCon1.source || node1 === fundNodeCon1.target) && fNCArray1.indexOf(countIndex1) === -1){
                          fNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });


                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray1.indexOf(i) > -1)
                    {
                      return "visible";
                    }
                    
                  });

                  //  For investing connections

                  var iNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      investingCon.forEach(function(investNodeCon1){
                        if((node1 === investNodeCon1.source || node1 === investNodeCon1.target) && iNCArray1.indexOf(countIndex1) === -1){
                          iNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });

                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray1.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      porucsCon.forEach(function(porucsNodeCon1){
                        if((node1 === porucsNodeCon1.source || node1 === porucsNodeCon1.target)&& pcNCArray1.indexOf(countIndex1) === -1){
                          pcNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });


                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray1.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      affilCon.forEach(function(affilNodeCon1){
                        if((node1 === affilNodeCon1.source || node1 === affilNodeCon1.target)&& aNCArray1.indexOf(countIndex1) === -1){
                          aNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });


                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray1.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  console.log(fNCArray1);
                                    console.log(iNCArray1);
                  console.log(pcNCArray1);
                                    console.log(aNCArray1);


        return this;}}).style("visibility", "visible");

 
          
    }
    if(!document.getElementById("cb_nonpro").checked)
    {
      d3.selectAll(".node").filter(function(d) { if (d.type === "Non-Profit") {


                      //  For funding connections

                  var fNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      fundingCon.forEach(function(fundNodeCon1){
                        if((node1 === fundNodeCon1.source || node1 === fundNodeCon1.target)&& fNCArray1.indexOf(countIndex1) === -1){
                          fNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });


                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray1.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                    
                  });

                  //  For investing connections

                  var iNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      investingCon.forEach(function(investNodeCon1){
                        if((node1 === investNodeCon1.source || node1 === investNodeCon1.target)&& iNCArray1.indexOf(countIndex1) === -1){
                          iNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });


                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray1.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      porucsCon.forEach(function(porucsNodeCon1){
                        if((node1 === porucsNodeCon1.source || node1 === porucsNodeCon1.target)&& pcNCArray1.indexOf(countIndex1) === -1){
                          pcNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });


                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray1.indexOf(i)>-1)
                    {

                      return "hidden";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray1 = [];
                  var countIndex1 = 0;

                  filteredNodes.forEach(function(node1){
                    if(node1.type === 'Non-Profit')
                    {
                      affilCon.forEach(function(affilNodeCon1){
                        if((node1 === affilNodeCon1.source || node1 === affilNodeCon1.target)&& aNCArray1.indexOf(countIndex1) === -1){
                          aNCArray1.push(countIndex1);//  store positions inside of array...
                        }
                        countIndex1++;
                      });
                      countIndex1 = 0;
                    }
                  });


                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray1.indexOf(i)>-1)
                    {
                    
                      return "hidden";
                    }
                  });

                  console.log(fNCArray1);
                                    console.log(iNCArray1);
                  console.log(pcNCArray1);
                                    console.log(aNCArray1);

                                    // return;

        return this;}}).style("visibility", "hidden");



                  
    }

  });

  d3.selectAll('#cb_forpro').on('click', function(){

    if(document.getElementById("cb_forpro").checked)
    {
      d3.selectAll(".node").filter(function(d) { if (d.type === "For-Profit") { 

              //  For funding connections

                  var fNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      fundingCon.forEach(function(fundNodeCon2){
                        if((node2 === fundNodeCon2.source || node2 === fundNodeCon2.target) && fNCArray2.indexOf(countIndex2) === -1){
                          fNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });


                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray2.indexOf(i) > -1)
                    {
                      return "visible";
                    }
                    
                  });

                  //  For investing connections

                  var iNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      investingCon.forEach(function(investNodeCon2){
                        if((node2 === investNodeCon2.source || node2 === investNodeCon2.target) && iNCArray2.indexOf(countIndex2) === -1){
                          iNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });

                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray2.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      porucsCon.forEach(function(porucsNodeCon2){
                        if((node2 === porucsNodeCon2.source || node2 === porucsNodeCon2.target)&& pcNCArray2.indexOf(countIndex2) === -1){
                          pcNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });


                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray2.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      affilCon.forEach(function(affilNodeCon2){
                        if((node2 === affilNodeCon2.source || node2 === affilNodeCon2.target)&& aNCArray2.indexOf(countIndex2) === -1){
                          aNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });


                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray2.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  console.log(fNCArray2);
                                    console.log(iNCArray2);
                  console.log(pcNCArray2);
                                    console.log(aNCArray2);


        return this;}}).style("visibility", "visible");

      
    }
        if(!document.getElementById("cb_forpro").checked)

    {
      d3.selectAll(".node").filter(function(d) { if (d.type === "For-Profit") {


                         //  For funding connections

                  var fNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      fundingCon.forEach(function(fundNodeCon2){
                        if((node2 === fundNodeCon2.source || node2 === fundNodeCon2.target)&& fNCArray2.indexOf(countIndex2) === -1){
                          fNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });


                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray2.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                    
                  });

                  //  For investing connections

                  var iNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      investingCon.forEach(function(investNodeCon2){
                        if((node2 === investNodeCon2.source || node2 === investNodeCon2.target)&& iNCArray2.indexOf(countIndex2) === -1){
                          iNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });


                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray2.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      porucsCon.forEach(function(porucsNodeCon2){
                        if((node2 === porucsNodeCon2.source || node2 === porucsNodeCon2.target)&& pcNCArray2.indexOf(countIndex2) === -1){
                          pcNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });


                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray2.indexOf(i)>-1)
                    {

                      return "hidden";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray2 = [];
                  var countIndex2 = 0;

                  filteredNodes.forEach(function(node2){
                    if(node2.type === 'For-Profit')
                    {
                      affilCon.forEach(function(affilNodeCon2){
                        if((node2 === affilNodeCon2.source || node2 === affilNodeCon2.target)&& aNCArray2.indexOf(countIndex2) === -1){
                          aNCArray2.push(countIndex2);//  store positions inside of array...
                        }
                        countIndex2++;
                      });
                      countIndex2 = 0;
                    }
                  });


                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray2.indexOf(i)>-1)
                    {
                    
                      return "hidden";
                    }
                  });

                  console.log(fNCArray2);
                                    console.log(iNCArray2);
                  console.log(pcNCArray2);
                                    console.log(aNCArray2);

                                    // return;


        return this;}}).style("visibility", "hidden");

                 
    }
    


  });

  d3.selectAll('#cb_gov').on('click', function(){

if(document.getElementById("cb_gov").checked)
    {
      d3.selectAll(".node").filter(function(d) { if (d.type === "Government") {

               // For funding connections

                  var fNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      fundingCon.forEach(function(fundNodeCon3){
                        if((node3 === fundNodeCon3.source || node3 === fundNodeCon3.target) && fNCArray3.indexOf(countIndex3) === -1){
                          fNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });


                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray3.indexOf(i) > -1)
                    {
                      return "visible";
                    }
                    
                  });

                  //  For investing connections

                  var iNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      investingCon.forEach(function(investNodeCon3){
                        if((node3 === investNodeCon3.source || node3 === investNodeCon3.target) && iNCArray3.indexOf(countIndex3) === -1){
                          iNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });

                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray3.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      porucsCon.forEach(function(porucsNodeCon3){
                        if((node3 === porucsNodeCon3.source || node3 === porucsNodeCon3.target)&& pcNCArray3.indexOf(countIndex3) === -1){
                          pcNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });


                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray3.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      affilCon.forEach(function(affilNodeCon3){
                        if((node3 === affilNodeCon3.source || node3 === affilNodeCon3.target)&& aNCArray3.indexOf(countIndex3) === -1){
                          aNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });


                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray3.indexOf(i) > -1)
                    {

                      return "visible";
                    }
                  });

                  console.log(fNCArray3);
                                    console.log(iNCArray3);
                  console.log(pcNCArray3);
                                    console.log(aNCArray3);


        return this;}}).style("visibility", "visible");

     

    }
        if(!document.getElementById("cb_gov").checked)
    {
      d3.selectAll(".node").filter(function(d) { if (d.type === "Government") {  



              //  For funding connections

                  var fNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      fundingCon.forEach(function(fundNodeCon3){
                        if((node3 === fundNodeCon3.source || node3 === fundNodeCon3.target)&& fNCArray3.indexOf(countIndex3) === -1){
                          fNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });


                  d3.selectAll('.fund').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(fNCArray3.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                    
                  });

                  //  For investing connections

                  var iNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      investingCon.forEach(function(investNodeCon3){
                        if((node3 === investNodeCon3.source || node3 === investNodeCon3.target)&& iNCArray3.indexOf(countIndex3) === -1){
                          iNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });


                  d3.selectAll('.invest').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(iNCArray3.indexOf(i) > -1)
                    {
                      return "hidden";
                    }
                  });

                  //  For partnerships/collaborations connections

                  var pcNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      porucsCon.forEach(function(porucsNodeCon3){
                        if((node3 === porucsNodeCon3.source || node3 === porucsNodeCon3.target)&& pcNCArray3.indexOf(countIndex3) === -1){
                          pcNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });


                  d3.selectAll('.porucs').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(pcNCArray3.indexOf(i)>-1)
                    {

                      return "hidden";
                    }
                  });

                  //  For affiliations connections

                  var aNCArray3 = [];
                  var countIndex3 = 0;

                  filteredNodes.forEach(function(node3){
                    if(node3.type === 'Government')
                    {
                      affilCon.forEach(function(affilNodeCon3){
                        if((node3 === affilNodeCon3.source || node3 === affilNodeCon3.target)&& aNCArray3.indexOf(countIndex3) === -1){
                          aNCArray3.push(countIndex3);//  store positions inside of array...
                        }
                        countIndex3++;
                      });
                      countIndex3 = 0;
                    }
                  });


                  d3.selectAll('.affil').style('visibility', function(l, i){
                  //  If the index of the funding line equals to the funding connection index...
                    if(aNCArray3.indexOf(i)>-1)
                    {
                    
                      return "hidden";
                    }
                  });

                  console.log(fNCArray3);
                                    console.log(iNCArray3);
                  console.log(pcNCArray3);
                                    console.log(aNCArray3);

                                    // return;

        return this;}}).style("visibility", "hidden");

}
  });

 d3.selectAll('#cb_emp, #cb_numtwit').on('click', function() 
{
      if(document.getElementById("cb_emp").checked)
      {
        node.attr("r", function(d) {if(d.numemp !== null) return empScale(parseInt(d.numemp)); else return "7";});
        textElement.attr('transform', function(d) {if(d.numemp !== null) return translateSVG(0, -(empScale(parseInt(d.numemp)) + 2));
          else return translateSVG(0, -(empScale(parseInt(7)) + 2));});
      }

      if(document.getElementById("cb_numtwit").checked)
      {
        node.attr("r", function(d) {if(d.followers !== null) return twitScale(parseInt(d.followers)); else return "7";});
        textElement.attr('transform', function(d) {if(d.followers !== null) return translateSVG(0, -(twitScale(parseInt(d.followers)) + 2));
          else return translateSVG(0, -(twitScale(parseInt(7)) + 2));
        });
      }
  });

});